package com.example.demo;

import javafx.scene.control.Button;

public class Proizvod {
    private int id_proizvoda;
    private String naziv_proizvoda;
    private String sifra_proizvoda;
    private int cena_proizvoda;
    private String proizvodjac_p;
    private int kolicina_p;
    private Button dugmence;


    public Proizvod(int id, String naziv, String sifra, int cena, String proizvodjac, int kolicina) {
        this.id_proizvoda = id;
        this.naziv_proizvoda = naziv;
        this.sifra_proizvoda = sifra;
        this.cena_proizvoda = cena;
        this.proizvodjac_p = proizvodjac;
        this.kolicina_p = kolicina;
        this.dugmence = new Button("Obrisi iz liste");


    }

    public Proizvod() {

    }

    public Button getDugmence() {
        return dugmence;
    }

    public void setDugmence(Button dugmence) {
        this.dugmence = dugmence;
    }

    public int getId_proizvoda() {
        return id_proizvoda;
    }

    public void setId_proizvoda(int id_proizvoda) {
        this.id_proizvoda = id_proizvoda;
    }

    public String getNaziv_proizvoda() {
        return naziv_proizvoda;
    }

    public void setNaziv_proizvoda(String naziv_proizvoda) {
        this.naziv_proizvoda = naziv_proizvoda;
    }

    public String getSifra_proizvoda() {
        return sifra_proizvoda;
    }

    public void setSifra_proizvoda(String sifra_proizvoda) {
        this.sifra_proizvoda = sifra_proizvoda;
    }

    public int getCena_proizvoda() {
        return cena_proizvoda;
    }

    public void setCena_proizvoda(int cena_proizvoda) {
        this.cena_proizvoda = cena_proizvoda;
    }

    public String getProizvodjac_p() {
        return proizvodjac_p;
    }

    public int getKolicina_p() {
        return kolicina_p;
    }

    public void setProizvodjac(String proizvodjac) {
        this.proizvodjac_p = proizvodjac;
    }

    public void setKolicina(int kolicina) {
        this.kolicina_p = kolicina;
    }

    @Override
    public String toString() {
        return "Proizvod{" +
                "id_proizvoda=" + id_proizvoda +
                ", naziv_proizvoda='" + naziv_proizvoda + '\'' +
                ", sifra_proizvoda='" + sifra_proizvoda + '\'' +
                ", cena_proizvoda=" + cena_proizvoda +
                ", proizvodjac='" + proizvodjac_p + '\'' +
                ", kolicina=" + kolicina_p +
                '}';
    }
}
