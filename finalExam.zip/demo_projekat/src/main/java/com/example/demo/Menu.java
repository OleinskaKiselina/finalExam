package com.example.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Menu extends Application {



    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("menu-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 520, 400);;
        Stage decorated = new Stage();
        decorated.initStyle(StageStyle.TRANSPARENT);
        decorated.setScene(scene);
        decorated.show();



    }


    public static void main(String[] args) {
        launch();
    }
}
