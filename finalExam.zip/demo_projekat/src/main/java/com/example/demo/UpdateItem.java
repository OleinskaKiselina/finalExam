package com.example.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class UpdateItem extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("search-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 700, 420);

        //;
        Stage transparent = new Stage();
        // transparent.setTitle("NASLOV");
        transparent.initStyle(StageStyle.TRANSPARENT);


        transparent.setScene(scene);
        transparent.show();
    }
}
