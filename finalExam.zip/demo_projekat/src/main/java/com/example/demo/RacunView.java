package com.example.demo;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class RacunView  extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Racun-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 500);;
        //;
        Stage transparent = new Stage();
       // transparent.setTitle("NASLOV");
        transparent.initStyle(StageStyle.TRANSPARENT);


        transparent.setScene(scene);
        transparent.show();

    }

}