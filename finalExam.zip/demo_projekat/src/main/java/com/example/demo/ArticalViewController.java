package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;

public class ArticalViewController {
    @FXML
    private TextField nazivP;
    @FXML
    private TextField sifraP;
    @FXML
    private TextField cenaP;
    @FXML
    private TextField proizvodjacP;
    @FXML
    private TextField kolicinaP;


    public void dodajProizvod_Baza() {
        String naziv = nazivP.getText().trim();
        String proizvodjac = proizvodjacP.getText().trim();
        String sifra = sifraP.getText().trim();
        if (naziv.length() == 0) {
            nazivP.setStyle("-fx-background-color:red");
        }
        if (sifra.length() != 4) {
            sifraP.setStyle("-fx-background-color:red");
            sifraP.setText("Molimo vas unesite duzinu sifre od 4 znaka bez razmaka");
        }
        if (proizvodjac.length() == 0) {
            proizvodjacP.setStyle("-fx-background-color:red");
            proizvodjacP.setText("Unesite barem 1 karakter ne racunajuci razmake");
        }
        int cena = -11111;
        try {
            cena = Integer.parseInt(cenaP.getText().trim());


        } catch (Exception e) {
            cena = -1;
            cenaP.setStyle("-fx-background-color:red");
        }
        String nazivProizvodjaca = nazivP.getText().trim();
        int kolicina = -11111;
        try {
            kolicina = Integer.parseInt(kolicinaP.getText().trim());

        } catch (Exception e) {
            kolicina = -1;
            kolicinaP.setStyle("-fx-background-color:red");
        }

        if (kolicina > 0 && cena > 0 && naziv.length() > 0 && sifra.length() == 4 && nazivProizvodjaca.length() > 0) {
            System.out.println("Dobar unos!!!");
            //code work connecting to mysql server
            dodavanjeProizvoda(naziv, sifra, cena, nazivProizvodjaca, kolicina);
        } else {
            System.out.println("Los unos!!!");
        }

    }

    private void dodavanjeProizvoda(String naziv, String sifra, int cena, String nazivProizvodjaca, int kolicina) {
        //izvrsavanje mysql upita i dodatna poruka
        DataBaseConnection db = new DataBaseConnection();
        Connection connection = db.getConnection();

        //creating message box
        Alert poruka = new Alert(Alert.AlertType.INFORMATION);
        poruka.setTitle("Naslov");
        poruka.setContentText("Proizvod uspesno dodat!");

        String provera = "SELECT COUNT(*) as brojac from `artikal` where sifra= '" + sifra+"'";


        //
        Statement statement = null;
        try {
            statement = connection.createStatement();
            ResultSet result = statement.executeQuery(provera);

            while (result.next()) {
                if (result.getInt("brojac") == 0) {

                    //kreirati funkciju koja vraca id radnika , ako je count 1 onda prosledjujemo na meni id_radnika
                    System.out.println("Jeste");
                    String Dodaj = "INSERT INTO `artikal`( `naziv`, `sifra`, `cena`, `proizvodjac`, `kolicina`) VALUES ('" + naziv + "','" + sifra + "','" + cena + "','" + nazivProizvodjaca + "','" + kolicina + "')";
                    //String Dodaj2="INSERT INTO `artikal`( `naziv`, `sifra`, `cena`,   `proizvodjac`, `kolicina`) VALUES ('izprograma','3344','200','NEmaprodsas','333')";
                    try {
                        PreparedStatement insert = connection.prepareStatement(Dodaj);
                        insert.executeUpdate();
                    } catch (SQLException e) {

                        poruka.setContentText("Proizvod sa ovom sifrom vec postoji u bazi!");
                    }
                    nazivP.clear();
                    sifraP.clear();
                    nazivP.clear();
                    kolicinaP.clear();
                    cenaP.clear();
                    proizvodjacP.clear();
                } else {
                    poruka.setContentText("Proizvod sa ovom sifrom vec postoji u bazi!");

                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        /// message for positive -> reseno tako sto ce odmah da predpostavimo da smo dodali
        poruka.show();


    }


    public void BojaDefault() {
        cenaP.setStyle("-fx-background-color:white");
        kolicinaP.setStyle("-fx-background-color:white");
        nazivP.setStyle("-fx-background-color:white");
        sifraP.setStyle("-fx-background-color:white");
        proizvodjacP.setStyle("-fx-background-color:white");
      //  proizvodjacP.setText("");
       // sifraP.setText("");

    }

    public void povratak_Meni(ActionEvent actionEvent) throws Exception {
        Stage st = (Stage) nazivP.getScene().getWindow();

        //hmm uzmem iz iz ovoga id_radenika iz ovog inta

        Menu menu = new Menu();
        Scene scene = st.getScene();
        st.setScene(null);
        st.hide();
        menu.start(st);


    }


}
