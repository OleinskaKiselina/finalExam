package com.example.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ArticalView extends Application {

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("artical-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 520, 400);
        //;
        Stage transparent = new Stage();
        transparent.initStyle(StageStyle.TRANSPARENT);


        transparent.setScene(scene);
        transparent.show();

    }

    public void GetStarted() {

        launch();

    }
}
