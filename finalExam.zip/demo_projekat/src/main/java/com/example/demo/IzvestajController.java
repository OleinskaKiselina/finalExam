package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class IzvestajController {

    @FXML
    private DatePicker kalendar;


    @FXML
    void Izlaz(ActionEvent event) throws Exception {
        Stage st = (Stage) kalendar.getScene().getWindow();
        Menu menu = new Menu();
        Scene scene = st.getScene();
        st.setScene(null);
        st.hide();
        menu.start(st);

    }

    @FXML
    void kreirajIzvestaj(ActionEvent event) {
        LocalDate datum = kalendar.getValue();

        if (datum == null) {
            Alert upozorenje = new Alert(Alert.AlertType.WARNING);
            upozorenje.setTitle("Prazno polje! ");
            upozorenje.setContentText("Molimo vas popunite polje ");
            kalendar.getEditor().clear();
            upozorenje.show();


        } else {
            // System.out.println("Izabrali ste "+datum.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).toString());
            //kreirati izvestaj za taj dan
            //1. ako je izvestaj prazan tj ima 0 proizvoda prodato tog dana ne stampa se izvestaj !
            DataBaseConnection db = new DataBaseConnection();
            Connection connection = db.getConnection();
            String SqlQuery = "Select count(*) as broj from `arhiva` WHERE datum='" + datum.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "'";
            Statement statement = null;
            ResultSet result = null;
            try {
                statement = connection.createStatement();
                result = statement.executeQuery(SqlQuery);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {

                while (result.next()) {
                    if (result.getInt("broj") == 0) {
                        Alert poruka = new Alert(Alert.AlertType.INFORMATION);
                        poruka.setContentText("Nema nista za trazeni datum");
                        poruka.show();
                    } else {
                        String query = "SELECT * from `arhiva` WHERE datum='" + datum.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "'";
                        result = statement.executeQuery(query);
                        int i = 1;
                        String datum2 = datum.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                        String naziv = "Izvestaj_za_" + datum2 + ".csv";
                        PrintWriter pw = new PrintWriter(naziv);
                        StringBuilder sb = new StringBuilder();
                        sb.append("redni broj");
                        sb.append(",");
                        sb.append("naziv proizvoda");
                        sb.append(",");
                        sb.append("kolicina");
                        sb.append(",");
                        sb.append("cena");
                        sb.append("\r\n");

                        while (result.next()) {
                            System.out.println(i + " : " + result.getString("ime_p") + "kolicina" + result.getString("kolicina") + "cena: " + result.getString("cena"));

                            sb.append(i);
                            sb.append(",");
                            sb.append(result.getString("ime_p"));
                            sb.append(",");
                            sb.append(result.getString("kolicina"));
                            sb.append(",");
                            sb.append(result.getString("cena"));
                            sb.append("\r\n");
                            i++;

                        }
                        String upit = "SELECT SUM(kolicina*cena) as zbir from arhiva where datum='" + datum.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "'";
                        result = statement.executeQuery(upit);
                        while (result.next()) {
                            sb.append("\r\n");

                            sb.append("Ukupna cena: " + result.getInt("zbir"));
                        }


                        pw.print(sb);
                        pw.close();
                        Alert poruka = new Alert(Alert.AlertType.INFORMATION);


                        File fajl = new File(naziv);
                        if (fajl.exists()) {
                            poruka.setContentText("Uspesno sacuvana datoteka " + naziv);
                        } else {
                            poruka.setContentText("Nije uspesno sacuvana datoteka " + naziv);

                        }

                        poruka.show();
                    }

                }

            } catch (SQLException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }


    }

    public void Stampa(ActionEvent actionEvent) {
    }
}
