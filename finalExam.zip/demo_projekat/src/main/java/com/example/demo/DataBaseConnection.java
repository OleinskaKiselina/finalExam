package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {
    public Connection dateBaseLink;

    public Connection getConnection() {
        String DataBaseName = "konekcija";
        String DataBaseUser = "root";
        String DataBasePassword = "";
        //  String url="jdbc:mysql://localhost/"+DataBaseName;

        final String url = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // dateBaseLink=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test", "root", "");
            dateBaseLink = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?user=root&password=");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return dateBaseLink;
    }

}
