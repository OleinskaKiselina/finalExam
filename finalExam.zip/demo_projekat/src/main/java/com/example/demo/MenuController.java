package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MenuController {

    @FXML
    Button exit;

    @FXML
    Button addProduct;

    @FXML

    public void Exit() {
        Stage stage = (Stage) addProduct.getScene().getWindow();

        stage.close();
    }

    @FXML
    public void addProductOppener() {
        Stage stage = (Stage) addProduct.getScene().getWindow();//creating new Scene


        //exitm
        //     ArticalViewController aw1=new ArticalViewController("Stefan Djukic");
        ArticalView aw = new ArticalView();
        try {
            stage.close();
            aw.start(stage);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void openUpdateArtical(ActionEvent actionEvent) {
        Stage stage = (Stage) addProduct.getScene().getWindow();//creating new Scene


        //exitm
        //     ArticalViewController aw1=new ArticalViewController("Stefan Djukic");
        UpdateItem ui = new UpdateItem();
        try {
            stage.close();
            ui.start(stage);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void OtvoriRacun(ActionEvent actionEvent) {
        Stage stage = (Stage) addProduct.getScene().getWindow();//creating new Scene

        RacunView rw = new RacunView();
        try {
            stage.close();
            rw.start(stage);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void UdjiIzvestaj(ActionEvent actionEvent) {
        Stage stage = (Stage) addProduct.getScene().getWindow();//creating new Scene

        IzvestajView iw = new IzvestajView();
        try {
            stage.close();
            iw.start(stage);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
