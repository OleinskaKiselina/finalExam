package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;


public class RacunController {


    static ObservableList<Proizvod> spisak_racun = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Proizvod, Integer> CENA;
    @FXML
    private TableColumn<Proizvod, Integer> KOLICINA;
    @FXML
    private TableColumn<Proizvod, String> NAZIV;
    @FXML
    private TableView<Proizvod> racunLista;
    @FXML
    private TableColumn<Proizvod, String> SIFRA;
    @FXML
    private TableColumn<Proizvod, String> UKLONI;
    @FXML
    private TextField pretrazi;
    @FXML
    private Label stanje;
    @FXML
    private Button exit;

    @FXML
    void NapraviRacun(ActionEvent event) {
        System.out.println("Racun je napravljen !");
        int cena = IznosTrenutni();
        System.out.println(cena);
        if (cena == 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Racun je prazan");
            alert.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Dodati Racun");
            alert.setResizable(false);
            alert.setContentText("Da li ste sigurni da zelite da odstampate racun ? ");
            Optional<ButtonType> result = alert.showAndWait();
            ButtonType button = result.orElse(ButtonType.CANCEL);

            if (button == ButtonType.OK) {

                DodajRacun();
            } else {

                alert.hide();
            }


        }


    }

    private void DodajRacun() {


        if (IznosTrenutni() > 0) {
            //create novi meni za upisivanje iznosa

            DataBaseConnection db = new DataBaseConnection();
            Connection connection = db.getConnection();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now = LocalDateTime.now();
            String datum = dtf.format(now);
            System.out.println("------------------------------------\n");
            System.out.println(datum);
            System.out.println("------------------------------------\n");

            String SqlQuery = "INSERT INTO `racun`( `datum`) VALUES ('" + datum + "')";
            PrintWriter pw;
            try {
                Statement statement = connection.createStatement();
                int result = statement.executeUpdate(SqlQuery);
                String pomocni = "SELECT MAX(id_racuna) as max from racun";
                ResultSet rr = statement.executeQuery(pomocni);
                int id = 0;
                while (rr.next()) {
                    id = rr.getInt("max");
                }
                pw = new PrintWriter("Racun_ID_" + id + ".txt");
                pw.write("------------------------------------\n");
                pw.write("Datum: " + datum + "\nID racuna: " + id + "\n");
                pw.write("------------------------------------\n");
                pw.write("ARTIKLI:\n");
                for (int i = 0; i < racunLista.getItems().size(); i++) {
                    String insert_racun = "INSERT INTO `racun_artikal`( `id_racuna`, `id`, `kolicina_prodat`) VALUES ('" + id + "','" + racunLista.getItems().get(i).getId_proizvoda() + "','" + racunLista.getItems().get(i).getKolicina_p() + "')";
                    String naziv = racunLista.getItems().get(i).getNaziv_proizvoda();
                    for (int j = naziv.length(); j < 20; j++) {
                        naziv += " ";
                    }
                    String cena = String.valueOf(racunLista.getItems().get(i).getCena_proizvoda());
                    for (int k = naziv.length(); k < 10; k++) {
                        naziv += " ";
                    }


                    pw.write(naziv + " " + cena + " x" + racunLista.getItems().get(i).getKolicina_p() + " : " + racunLista.getItems().get(i).getCena_proizvoda() * racunLista.getItems().get(i).getKolicina_p() + "\n");

                    statement.executeUpdate(insert_racun);
                    String tekst = "INSERT INTO `arhiva`( `ime_p`, `kolicina`, `cena`, `datum`) VALUES ('" + racunLista.getItems().get(i).getNaziv_proizvoda() + "','" + racunLista.getItems().get(i).getKolicina_p() + "','" + racunLista.getItems().get(i).getCena_proizvoda() + "','" + datum + "')";
                    statement.executeUpdate(tekst);

                }
                pw.write("------------------------------------\n");
                pw.write("IZNOS: " + IznosTrenutni());
                pw.flush();
                pw.close();

                racunLista.getItems().clear();
                IznosTrenutni();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


        }


    }

    @FXML
    void Pretraga(ActionEvent event) {
        System.out.println("Pretraga kliknuta");
        //create a custom window
        DodavanjeArtikla dodavanjeArtikla = new DodavanjeArtikla();
        dodavanjeArtikla.display(pretrazi.getText().trim());

    }

    public void Izlaz(ActionEvent actionEvent) throws Exception {
        Stage st = (Stage) exit.getScene().getWindow();

        //hmm uzmem iz iz ovoga id_radenika iz ovog inta

        Menu menu = new Menu();
        Scene scene = st.getScene();
        st.setScene(null);
        st.hide();
        menu.start(st);
    }

    int IznosTrenutni() {
        int cena = 0;
        if (spisak_racun.size() == 0) {
            // System.out.println("prazan spisak ");
        } else {
            System.out.println("isips");
            for (Proizvod p : spisak_racun) {
                cena += p.getCena_proizvoda() * p.getKolicina_p();
                //  System.out.println(p.toString());
            }
            // System.out.println("ispis");
        }
        System.out.println("Totalni racun: " + cena);
        stanje.setText("Totalni racun: " + cena);

        return cena;

    }

    class DodavanjeArtikla {
        void display(String tekst) {
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setMaxWidth(500);

            GridPane layout = new GridPane();
            Button button = new Button("Dodaj u korpu");

            //stage.close();

            String nazivProizvoda_i_proizvodjaca = "ARTIKAL: ";

            DataBaseConnection db = new DataBaseConnection();
            Connection connection = db.getConnection();
            String SqlQuery = "SELECT COUNT(*) as broj FROM `artikal` WHERE sifra LIKE '%" + tekst.trim() + "%' OR naziv LIKE '%" + tekst.trim() + "%'";
            Label poruka = new Label();
            Statement statement = null;
            try {
                statement = connection.createStatement();
                ResultSet result = statement.executeQuery(SqlQuery);
                while (result.next()) {
                    if (result.getInt("broj") == 0) {
                        System.out.println("Broj artikala" + result.getInt("broj"));
                        poruka.setText("NE postoji artikal");
                        layout.add(poruka, 0, 1);
                    } else {
                        System.out.println("Ovde treba kreirati sada Tabelu !!!!");
                        poruka.setText("Ovde ce sada da bude minijaturna tabelica");
                        TableView<Proizvod> tableView = new TableView();
                        tableView.setPrefWidth(700);

                        TableColumn<Proizvod, Integer> id = new TableColumn<>();
                        TableColumn<Proizvod, String> naziv = new TableColumn<>();
                        naziv.setText("Naziv");
                        TableColumn<Proizvod, String> sifra = new TableColumn<>();
                        sifra.setText("sifra");
                        TableColumn<Proizvod, Integer> cena = new TableColumn<>();
                        cena.setText("cena");

                        TableColumn<Proizvod, Integer> kolicina = new TableColumn<>();//probamo sa textfieldom koji ce da mu setuje vrednost

                        kolicina.setText("kolicina");
                        TableColumn<Proizvod, String> editCol = new TableColumn<>();
                        tableView.getColumns().add(naziv);
                        tableView.getColumns().add(sifra);
                        tableView.getColumns().add(cena);
                        tableView.getColumns().add(kolicina);
                        tableView.getColumns().add(editCol);
                        //tableView.getColumns().add(id);
                        ObservableList<Proizvod> data = FXCollections.observableArrayList();
                        naziv.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("naziv_proizvoda"));
                        sifra.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("sifra_proizvoda"));
                        cena.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("cena_proizvoda"));
                        kolicina.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("kolicina_p"));
                        id.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("id_proizvoda"));
                        //novi statement

                        db = new DataBaseConnection();
                        connection = db.getConnection();
                        String upitTabela = "SELECT * FROM `artikal` WHERE sifra LIKE '%" + tekst.trim() + "%' OR naziv LIKE '%" + tekst.trim() + "%'";
                        statement = connection.createStatement();
                        result = statement.executeQuery(upitTabela);
                        int brojac = 0;
                        while (result.next()) {
                            Proizvod p = new Proizvod();
                            TextField unos = new TextField();
                            p.setNaziv_proizvoda(result.getString("naziv"));
                            p.setSifra_proizvoda(result.getString("sifra"));
                            p.setCena_proizvoda(result.getInt("cena"));
                            p.setKolicina(result.getInt("kolicina"));
                            p.setId_proizvoda(result.getInt("id"));
                            // p.setKolicina(1);


                            //System.out.println(p.toString());
                            data.add(p);

                            brojac++;
                        }

                        System.out.println("Broj proizvoda " + brojac);


                        layout.add(tableView, 0, 1);
                        Callback<TableColumn<Proizvod, String>, TableCell<Proizvod, String>> cellFoctory = (TableColumn<Proizvod, String> param) -> {
                            // make cell containing buttons
                            final TableCell<Proizvod, String> cell = new TableCell<Proizvod, String>() {
                                @Override
                                public void updateItem(String item, boolean empty) {
                                    super.updateItem(item, empty);
                                    //that cell created only on non-empty rows
                                    if (empty) {
                                        setGraphic(null);
                                        setText(null);

                                    } else {

                                        TextField unos = new TextField();
                                        Proizvod data = getTableView().getItems().get(getIndex());
                                        int Kolicina = data.getKolicina_p();
                                        unos.setText(String.valueOf(Kolicina));
                                        Button dodavanje = new Button("Dodati u korpu");

                                        HBox pane = new HBox(unos, dodavanje);
                                        setGraphic(pane);

                                        // cell.inserts(deleteIcon);
                                        dodavanje.setOnAction(new EventHandler<ActionEvent>() {
                                            @Override
                                            public void handle(ActionEvent actionEvent) {
                                                Proizvod data = getTableView().getItems().get(getIndex());
                                                String naziv = data.getNaziv_proizvoda();
                                                int kolicina = data.getKolicina_p();
                                                int uneta_kolicina = 0;
                                                try {
                                                    uneta_kolicina = Integer.valueOf(unos.getText().trim());
                                                } catch (Exception exasda) {
                                                    uneta_kolicina = -1;
                                                    Alert poruka = new Alert(Alert.AlertType.INFORMATION);
                                                    poruka.setContentText("Molimo vas unesite validnu vrednos vecu od 0 bez slova");
                                                    poruka.show();
                                                }
                                                if (uneta_kolicina > 0 && uneta_kolicina <= data.getKolicina_p()) {
                                                    System.out.println(naziv + " : " + kolicina + " uneta->" + uneta_kolicina);
                                                    //     komentar
                                                    //racunLista.getItems().clear();
                                                    Proizvod p = new Proizvod();
                                                    p.setId_proizvoda(data.getId_proizvoda());
                                                    //          System.out.println("ID PROZIVODA JE : "+p.getId_proizvoda());
                                                    p.setNaziv_proizvoda(data.getNaziv_proizvoda());
                                                    p.setSifra_proizvoda(data.getSifra_proizvoda());
                                                    p.setCena_proizvoda(data.getCena_proizvoda());
                                                    int stata = data.getKolicina_p();
                                                    p.setKolicina(data.getKolicina_p());
                                                    p.setProizvodjac(data.getProizvodjac_p());
                                                    NAZIV.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("naziv_proizvoda"));
                                                    SIFRA.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("sifra_proizvoda"));
                                                    CENA.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("cena_proizvoda"));
                                                    KOLICINA.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("kolicina_p"));
                                                    int stara = p.getKolicina_p();
                                                    p.setKolicina(uneta_kolicina);
                                                    boolean exist = false;


                                                    ObservableList<Proizvod> pom = spisak_racun;
                                                    System.out.println("Spisak DUZINA " + pom.size());

                                                    if (pom.size() > 0) {
                                                        for (int i = 0; i < pom.size(); i++) {
                                                            if (pom.get(i).getSifra_proizvoda().equals(p.getSifra_proizvoda())) {

                                                                exist = true;
                                                                System.out.println("Kolicina: u spisku");
                                                                System.out.println(pom.get(i).getKolicina_p());
                                                                // stara = Integer.valueOf(pom.get(i).getKolicina_p());
                                                                System.out.println("STARA KOLICINA JE : " + stara);
                                                                pom.get(i).setKolicina(pom.get(i).getKolicina_p() + uneta_kolicina);
                                                            /*
                                                            pom.remove(pom.get(i));
                                                            pom.add(p);

                                                             */
                                                                System.out.println("Koliinca nakon dodavanja ");
                                                                System.out.println(pom.get(i).getKolicina_p());
                                                                p = pom.get(i);
                                                                pom.remove(i);//removing element with that index
                                                                pom.add(p);
                                                                break;


                                                                // racunLista.setItems(spisak_racun);


                                                            }
                                                        }
                                                    }
                                                    if (exist == false) {
                                                        pom.add(p);


                                                    }
                                                    // racunLista.getItems().clear();
                                                    spisak_racun = null;
                                                    spisak_racun = pom;//hmm dodati ovde funkciju brisanja !!!
                                                    Callback<TableColumn<Proizvod, String>, TableCell<Proizvod, String>> cellFoctory = (TableColumn<Proizvod, String> param) -> {
                                                        // make cell containing buttons
                                                        final TableCell<Proizvod, String> cell = new TableCell<Proizvod, String>() {
                                                            @Override
                                                            public void updateItem(String item, boolean empty) {
                                                                super.updateItem(item, empty);
                                                                //that cell created only on non-empty rows
                                                                if (empty) {
                                                                    setGraphic(null);
                                                                    setText(null);

                                                                } else {
                                                                    Button delete = new Button("Obrisati");


                                                                    HBox pane = new HBox(delete);
                                                                    setGraphic(pane);

                                                                    int id = 0;
                                                                    delete.setOnAction(new EventHandler<ActionEvent>() {
                                                                        @Override
                                                                        public void handle(ActionEvent actionEvent) {
                                                                            Proizvod p = getTableView().getItems().get(getIndex());
                                                                            int id = p.getId_proizvoda();
                                                                            System.out.println(p);
                                                                            System.out.println("Klik dugmeta" + id);

                                                                            DataBaseConnection db = new DataBaseConnection();
                                                                            Connection connection = db.getConnection();
                                                                            String upitKolicina = "SELECT kolicina as broj FROM `artikal` WHERE id=" + id;
                                                                            int stara_kolicina = 0;
                                                                            Statement statement = null;
                                                                            try {
                                                                                statement = connection.createStatement();
                                                                                ResultSet result = statement.executeQuery(upitKolicina);
                                                                                while (result.next())
                                                                                    stara_kolicina = result.getInt("broj");


                                                                                statement = connection.createStatement();
                                                                                int vrednost = stara_kolicina + p.getKolicina_p();
                                                                                System.out.println("-----------------------------------------");
                                                                                System.out.println("STARA KOLICINA: " + stara_kolicina);
                                                                                System.out.println("KOLICINA KOJA JE BILA UZETA" + p.getKolicina_p());
                                                                                System.out.println("UPDATE ID: " + id);
                                                                                System.out.println("------------------------------------------");
                                                                                String update = "UPDATE `artikal` SET `kolicina`='" + vrednost + "' WHERE id=" + id;
                                                                                int result2 = statement.executeUpdate(update);


                                                                            } catch (SQLException e) {
                                                                                e.printStackTrace();
                                                                            }

                                                                            int red = getTableRow().getIndex();
                                                                            //uraditi dva sql upita koja vracaju bazu u predhodno stanje i testirati
                                                                            System.out.println("RED: " + red);

                                                                            spisak_racun.remove(red);
                                                                            IznosTrenutni();


                                                                        }
                                                                    });

                                                                }
                                                            }


                                                        };
                                                        return cell;
                                                    };
                                                    UKLONI.setCellFactory(cellFoctory);
                                                    racunLista.setItems(spisak_racun);
                                                    IznosTrenutni();
                                                    //izvristi sql upit
                                                    DataBaseConnection db = new DataBaseConnection();
                                                    Connection connection = db.getConnection();
                                                    //        System.out.println("STARA JE "+stara);
                                                    int rezultat = stara - uneta_kolicina;
                                                    String upit_update = "UPDATE `artikal` SET `kolicina`='" + rezultat + "' WHERE id=" + p.getId_proizvoda();
                                                    Statement statement = null;
                                                    try {
                                                        statement = connection.createStatement();
                                                        int result = statement.executeUpdate(upit_update);
                                                        if (result == 0) {
                                                            System.out.println("Neuspesan update");
                                                        } else {
                                                            System.out.println("Uspesan update");
                                                        }
                                                    } catch (SQLException e) {
                                                        e.printStackTrace();
                                                    }


                                                    stage.close();


                                                } else {
                                                    Alert prevelika_vrednost = new Alert(Alert.AlertType.INFORMATION);
                                                    prevelika_vrednost.setContentText("Prevelika vrednost u odnosu na dostupnu kolicinu");
                                                    prevelika_vrednost.show();
                                                }

                                            }
                                        });

                                    }
                                }

                            };
                            return cell;
                        };
                        editCol.setCellFactory(cellFoctory);
                        tableView.setItems(data);


                    }
                    //ovde dodati kod


                }


            } catch (SQLException e) {
                e.printStackTrace();
            }


            Label label1 = new Label(nazivProizvoda_i_proizvodjaca);
            Label label2 = new Label("Uneti promenu:");
            String id = "izabrati cena/kolicina";
            Label label3 = new Label(id);


            layout.setPadding(new Insets(10, 10, 10, 10));
            layout.setVgap(5);
            layout.setHgap(5);


            // layout.add(text, 1,2);

            Scene scene = new Scene(layout, 600, 400);
            stage.setTitle("Dodavanje Artikla");

            stage.setScene(scene);
            stage.showAndWait();


        }

    }

}
