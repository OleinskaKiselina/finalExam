package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

public class UpdateItemController implements Initializable {
    public static int brojac = 0;
    static TableColumn listaBrisanja = new TableColumn("Obrisi");
    ObservableList<Proizvod> data = FXCollections.observableArrayList();
    @FXML
    private TableView<Proizvod> lista;
    @FXML
    private TableColumn<Proizvod, Integer> cena;
    @FXML
    private TableColumn<Proizvod, Integer> id_p;
    @FXML
    private TableColumn<Proizvod, Integer> kolicina;
    @FXML
    private TableColumn<Proizvod, String> naziv;
    @FXML
    private TableColumn<Proizvod, String> proizvodjac;
    @FXML
    private TableColumn<Proizvod, String> sifra;
    @FXML
    private TextField unos;
    //editCol
    @FXML
    private TableColumn<Proizvod, String> editCol;
    @FXML
    private Button exit;

    @FXML
    public void PrikazListe() {
        String sadrzaj = unos.getText().trim();
        System.out.println(sadrzaj);
        brojac++;
        String pom = String.valueOf(brojac);
        Text t1 = new Text(pom);
        System.out.println("Pritisnuli ste : " + pom);
        // refresh
        lista.getItems().clear();
        //

        Pretraga(sadrzaj);

    }

    public void Pretraga(String unos) {


        id_p.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("id_proizvoda"));
        naziv.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("naziv_proizvoda"));
        sifra.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("sifra_proizvoda"));
        cena.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("cena_proizvoda"));
        proizvodjac.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("proizvodjac_p"));
        kolicina.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("kolicina_p"));

        DataBaseConnection db = new DataBaseConnection();
        Connection connection = db.getConnection();
        String SqlQuery = "";
        if (unos.length() == 0) {
            SqlQuery = "SELECT * FROM artikal ";

        } else {
            SqlQuery = "SELECT * FROM `artikal` WHERE sifra like '%" + unos + "%' or naziv like '%" + unos + "%'";
        }


        try {
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(SqlQuery);

            while (result.next()) {

                Proizvod p = new Proizvod();
                p.setId_proizvoda(result.getInt("id"));
                p.setNaziv_proizvoda(result.getString("naziv"));
                p.setSifra_proizvoda(result.getString("sifra"));
                p.setCena_proizvoda(result.getInt("cena"));
                p.setProizvodjac(result.getString("proizvodjac"));
                p.setKolicina(result.getInt("kolicina"));
                // p.setKolicina(1);


                //System.out.println(p.toString());
                data.add(p);


            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


        //adding button delete !
        //
        //add cell of button edit
        Callback<TableColumn<Proizvod, String>, TableCell<Proizvod, String>> cellFoctory = (TableColumn<Proizvod, String> param) -> {
            // make cell containing buttons
            final TableCell<Proizvod, String> cell = new TableCell<Proizvod, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    //that cell created only on non-empty rows
                    if (empty) {
                        setGraphic(null);
                        setText(null);

                    } else {
                        Button delete = new Button("Obrisati");
                        Button updateIcon = new Button("Izmeniti");

                        HBox pane = new HBox(delete, updateIcon);
                        setGraphic(pane);
                        updateIcon.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent actionEvent) {
                                Proizvod data = getTableView().getItems().get(getIndex());
                                int id_product = data.getId_proizvoda();

                                System.out.println("Kliknuli ste na izmeni -> " + id_product);
                                IzmenaProizvodaKreirajDialog(id_product);

                            }
                        });
                        delete.setOnMouseClicked((MouseEvent event) -> {

                            Proizvod data = getTableView().getItems().get(getIndex());
                            int id_product = data.getId_proizvoda();
                            System.out.println("selectedData: " + data.getId_proizvoda());
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.setTitle("Obrisati artikal");
                            alert.setHeaderText("Da li zelite da obrisete artikal? ");
                            alert.setResizable(false);
                            alert.setContentText("Naziv artikla : " + data.getProizvodjac_p());

                            Optional<ButtonType> result = alert.showAndWait();
                            ButtonType button = result.orElse(ButtonType.CANCEL);

                            if (button == ButtonType.OK) {
                                System.out.println("Ok pressed");
                                DeleteProizvod(id_product);
                            } else {
                                System.out.println("canceled");
                            }

                        });
                    }
                }


            };
            return cell;
        };
        editCol.setCellFactory(cellFoctory);
        lista.setItems(data);


    }

    private void DeleteProizvod(int id_product) {
        DataBaseConnection db = new DataBaseConnection();
        Connection connection = db.getConnection();
        System.out.println("Izbor artikala id je : " + id_product);
        String SqlQuery = "DELETE FROM `artikal` WHERE id=" + id_product;


        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(SqlQuery);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("Uspesno obrisan artikal!!!");
        alert.show();
        //refreshing page
        RefreshPage();
        //  Pretraga("nista ");
        // Pretraga("XXXXXXXXXXXXXXXXXXXXX");
    }

    private void RefreshPage() {
        data.clear();


        id_p.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("id_proizvoda"));
        naziv.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("naziv_proizvoda"));
        sifra.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("sifra_proizvoda"));
        cena.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("cena_proizvoda"));
        proizvodjac.setCellValueFactory(new PropertyValueFactory<Proizvod, String>("proizvodjac_p"));
        kolicina.setCellValueFactory(new PropertyValueFactory<Proizvod, Integer>("kolicina_p"));

        DataBaseConnection db = new DataBaseConnection();
        Connection connection = db.getConnection();
        String SqlQuery = "";

        SqlQuery = "SELECT * FROM artikal ";


        try {
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(SqlQuery);

            while (result.next()) {

                Proizvod p = new Proizvod();
                p.setId_proizvoda(result.getInt("id"));
                p.setNaziv_proizvoda(result.getString("naziv"));
                p.setSifra_proizvoda(result.getString("sifra"));
                p.setCena_proizvoda(result.getInt("cena"));
                p.setProizvodjac(result.getString("proizvodjac"));
                p.setKolicina(result.getInt("kolicina"));


                //System.out.println(p.toString());
                data.add(p);


            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


        //adding button delete !
        //
        //add cell of button edit
        Callback<TableColumn<Proizvod, String>, TableCell<Proizvod, String>> cellFoctory = (TableColumn<Proizvod, String> param) -> {
            // make cell containing buttons
            final TableCell<Proizvod, String> cell = new TableCell<Proizvod, String>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    //that cell created only on non-empty rows
                    if (empty) {
                        setGraphic(null);
                        setText(null);

                    } else {

                        Button deleteIcon = new Button("Obrisati");
                        Button updateIcon = new Button("Izmeniti");

                        HBox pane = new HBox(deleteIcon, updateIcon);
                        setGraphic(pane);

                        // cell.inserts(deleteIcon);
                        updateIcon.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent actionEvent) {
                                Proizvod data = getTableView().getItems().get(getIndex());
                                int id_product = data.getId_proizvoda();
                                IzmenaProizvodaKreirajDialog(id_product);

                                System.out.println("Kliknuli ste na izmeni -> " + id_product);

                            }
                        });
                        deleteIcon.setOnMouseClicked((MouseEvent event) -> {

                            Proizvod data = getTableView().getItems().get(getIndex());
                            int id_product = data.getId_proizvoda();
                            System.out.println("selectedData: " + data.getId_proizvoda());
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.setTitle("Obrisati artikal");
                            alert.setHeaderText("Da li zelite da obrisete artikal? ");
                            alert.setResizable(false);
                            alert.setContentText("Naziv artikla : " + data.getProizvodjac_p());

                            Optional<ButtonType> result = alert.showAndWait();
                            ButtonType button = result.orElse(ButtonType.CANCEL);

                            if (button == ButtonType.OK) {
                                System.out.println("Ok pressed");
                                DeleteProizvod(id_product);
                            } else {
                                System.out.println("canceled");
                            }

                        });
                    }
                }

            };
            return cell;
        };
        editCol.setCellFactory(cellFoctory);
        lista.setItems(data);


    }

    private void IzmenaProizvodaKreirajDialog(int id_product) {

        AlertDialog aw = new AlertDialog();
        aw.display(id_product);


    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        RefreshPage();
    }

    public void NazadUMeniUpdate(ActionEvent actionEvent) throws Exception {
        Stage st = (Stage) exit.getScene().getWindow();

        //hmm uzmem iz iz ovoga id_radenika iz ovog inta

        Menu menu = new Menu();
        Scene scene = st.getScene();
        st.setScene(null);
        st.hide();
        menu.start(st);


    }

    class AlertDialog {
        void display(int id_product) {
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setMaxWidth(500);
            TextField text = new TextField();
            String[] optionsToChoose = {"cena", "kolicina"};
            ComboBox<String> jComboBox = new ComboBox();


            ArrayList<String> lista = new ArrayList<>();
            lista.add("cena");
            lista.add("kolicina");
            jComboBox.getItems().add("cena");
            jComboBox.getItems().add("kolicina");
            jComboBox.getSelectionModel().select(0);


            Button button = new Button("Izvrsi izmenu ");
            button.setOnAction(e -> {

                System.out.println("Uneli ste sledece stvari " + text.getText());
                //  System.out.println("Izbor iz menija "+jComboBox.getSelectionModel().getSelectedItem().trim());

                String opcija = jComboBox.getSelectionModel().getSelectedItem().trim();
                int unos = -2;
                try {
                    unos = Integer.parseInt(text.getText());
                } catch (Exception exp) {
                    Alert alert;
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("Greska: molimo vas unesite celobrojnu vrednost na primer 100");
                    alert.show();
                    text.clear();//ociscen
                    unos = -1;
                }
                if (unos > 0 && jComboBox.getSelectionModel().getSelectedItem().trim() != null) {


                    //izvrsiti update
                    DataBaseConnection db = new DataBaseConnection();
                    Connection connection = db.getConnection();
                    //String SqlQuery="UPDATE artikal set "+opcija+"="+unos+"where id="+id_product;

                    String sql = "UPDATE `artikal` SET `" + opcija + "`='" + unos + "' WHERE id=" + id_product;

                    Statement statement = null;
                    try {
                        statement = connection.createStatement();
                        statement.executeUpdate(sql);
                    } catch (Exception exp) {
                        System.out.println("Greska" + exp.getMessage());
                        Alert poruka = new Alert(Alert.AlertType.WARNING);
                        poruka.setContentText(exp.getMessage());
                        poruka.show();
                    }
                    stage.close();
                    RefreshPage();//uraditi obavezno

                } else {
                    Alert poruka = new Alert(Alert.AlertType.INFORMATION);
                    poruka.setContentText(" Molimo vas da koristite vrednosti vece od 0 za kolicinu ");
                    poruka.show();
                }

                //stage.close();
            });
            String nazivProizvoda_i_proizvodjaca = "ARTIKAL: ";

            DataBaseConnection db = new DataBaseConnection();
            Connection connection = db.getConnection();
            String SqlQuery = "SELECT * FROM `artikal` WHERE id=" + id_product;

            Statement statement = null;
            try {
                statement = connection.createStatement();
                ResultSet result = statement.executeQuery(SqlQuery);
                while (result.next()) {

                    nazivProizvoda_i_proizvodjaca += result.getString("naziv");
                    nazivProizvoda_i_proizvodjaca += " " + result.getString("proizvodjac");

                }


            } catch (SQLException e) {
                e.printStackTrace();
            }


            Label label1 = new Label(nazivProizvoda_i_proizvodjaca);
            Label label2 = new Label("Uneti promenu:");
            String id = String.valueOf("izabrati cena/kolicina");
            Label label3 = new Label(id);

            GridPane layout = new GridPane();

            layout.setPadding(new Insets(10, 10, 10, 10));
            layout.setVgap(5);
            layout.setHgap(5);

            layout.add(jComboBox, 1, 1);
            layout.add(text, 1, 2);
            layout.add(button, 1, 3);
            layout.add(label1, 1, 0);
            layout.add(label2, 0, 1);
            layout.add(label3, 0, 2);

            Scene scene = new Scene(layout, 300, 300);
            stage.setTitle("Izmena sadrzaja : )");

            stage.setScene(scene);
            stage.showAndWait();


        }

    }
}

