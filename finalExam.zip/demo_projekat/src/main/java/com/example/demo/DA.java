package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DA {


    @FXML
    private TextField user;
    @FXML
    private Button Izlaz;

    @FXML
    private PasswordField password;
    @FXML
    private Label message;


    @FXML
    public void Konekcija() {
        System.out.println("Hello World pritisnut");


        System.out.println("Uneli ste za usera : " + user.getText());
        System.out.println("Uneli ste za sifru : " + password.getText());
        if (user.getText().trim().length() > 0 && password.getText().trim().length() > 0) {
            ConnectToSQL();

        } else {
            message.setText("Molimo popunite sva polja ");
            message.setStyle("-fx-text-fill: red");


        }
    }


    @FXML
    public void Izadji() {
        Stage scene = (Stage) Izlaz.getScene().getWindow();
        scene.close();

    }

    public void ConnectToSQL() {
        DataBaseConnection db = new DataBaseConnection();
        Connection connection = db.getConnection();
        String SqlQuery = "SELECT COUNT(*) FROM `radnici` WHERE username='" + user.getText().trim() + "' and password='" + password.getText().trim() + "'";


        try {
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(SqlQuery);

            while (result.next()) {
                if (result.getInt(1) == 1) {
                    message.setText("Uspesno ste se ulogovali!");
                    message.setStyle("-fx-text-fill: green");
                    Stage st = (Stage) message.getScene().getWindow();
                    st.close();//exit
                    //kreirati funkciju koja vraca id radnika , ako je count 1 onda prosledjujemo na meni id_radnika


                    String podaci = VratiImeiPRezime();
                    System.out.println("?");
                    System.out.println(podaci);
                    System.out.println("?");

                    Menu menu = new Menu();


                    menu.start(st);

                    // aw.start();//


                } else {
                    message.setText("Korisnik ne postoji u bazi ");
                    message.setStyle("-fx-text-fill: red");


                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String VratiImeiPRezime() {
        DataBaseConnection db = new DataBaseConnection();
        Connection connection = db.getConnection();
        String ime_prezime = "";
        String Upit = "SELECT ime,prezime FROM `radnici` WHERE username='" + user.getText().trim() + "' and password='" + password.getText().trim() + "'";
        Statement statement2 = null;
        try {
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(Upit);
            String ime = "NEPOZNATO";
            String prezime = "Dusane";
            System.out.println("------------------------------");
            while (result.next()) {
                ime = result.getString("ime");
                prezime = result.getString("prezime");
                System.out.println(ime);
                System.out.println(prezime);
                System.out.println("KRAJ!!!!!!");
                ime_prezime += ime + " " + prezime;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ime_prezime;

    }


}